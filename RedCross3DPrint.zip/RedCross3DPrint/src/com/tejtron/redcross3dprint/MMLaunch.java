package com.tejtron.redcross3dprint;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MMLaunch extends Activity {
    
	final Context context1 = this;
		private WebView webView;
	 
		public void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			setContentView(R.layout.activity_mmlaunch);
	 
		//	webView.setWebViewClient(new WebViewClient());
	
			webView = (WebView) findViewById(R.id.webView1);
			
			 webView.setWebViewClient(new AWebViewClient());
			 webView.getSettings().setJavaScriptEnabled(true);
			 //webView.clearCache(true);
			 //webView.clearHistory();
			 webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
			  openURL();
		}
		
		 @Override
		    public boolean onKeyDown(int keyCode, KeyEvent event) {
			 if ((keyCode == KeyEvent.KEYCODE_BACK) && webView.canGoBack()) {
			     //   webView.goBack();
				 Intent intent = new Intent(context1, MainActivity.class);
					startActivity(intent);
			        return true;
			    }   
			 
			 
		        return super.onKeyDown(keyCode, event);
		    }

		
		private void openURL() {
			  webView.loadUrl("http://ec2-54-196-176-100.compute-1.amazonaws.com/");
			 }
		
		
		private class AWebViewClient extends WebViewClient {
			  @Override
			  public boolean shouldOverrideUrlLoading(WebView view, String url) {
			   view.loadUrl(url);
			   return true;
			  }
			 }

	 
	}