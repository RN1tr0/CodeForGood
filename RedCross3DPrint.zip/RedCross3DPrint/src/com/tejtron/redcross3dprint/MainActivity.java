package com.tejtron.redcross3dprint;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

	private Button button;
	protected static boolean netAvailable = false;
	protected static boolean checkThread = false;
	
//	MainActivity ma=new MainActivity();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		String str = "\u2193";

		TextView tv = (TextView) findViewById(R.id.textView2);
		tv.setText("Click below to proceed " + str);

		button = (Button) findViewById(R.id.buttonUrl);
		
		button.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				displayData();
				
				if(netAvailable==true) {
				Intent intent = new Intent(MainActivity.this, MMLaunch.class);
				startActivity(intent);
				}
				else {
					netAvailable=false;
					setToastMessage("Netowrk not available");
			
				}
			}

		});

	}
	
	
	public  void setToastMessage(String message) {
		Toast.makeText(this,message, Toast.LENGTH_SHORT)
		.show();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		
		int id = item.getItemId();
		
		if (id == R.id.action_settings) {
			startActivityForResult(new Intent(android.provider.Settings.ACTION_SETTINGS), 0);
			return true;
		}
		if (id == R.id.donate) {
			Uri uriDonate = Uri.parse("https://www.redcross.org/donate/fire-donate-d?scode=RS"
										 +"A14100E005&subcode=Oct2014FireSafetyAppea"
		                                 +"lASpot&campname=firedonate&campmedium=aspot_unassigned");
			Intent launchBrowser = new Intent(Intent.ACTION_VIEW, uriDonate);
			startActivity(launchBrowser);
			return true;
		}
		if (id == R.id.about_us) {
			Uri uriAbout = Uri.parse("http://en.wikipedia.org/wiki/American_Red_Cross");
			Intent launchBrowser = new Intent(Intent.ACTION_VIEW, uriAbout);
			startActivity(launchBrowser);
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	
	 void displayData() {
			ConnectivityManager cn = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
			NetworkInfo nf = cn.getActiveNetworkInfo();
			
			if (nf != null && nf.isConnected() == true) {
				MainActivity.netAvailable = true;
			} else {
				MainActivity.netAvailable = false;
	        //    ma.setToastMessage("Netowrk not available");
			}
		}
}